# =============================================================================
# TASK 4: Disease Prediction from Medical Data — Heart Disease
# CodeAlpha Machine Learning Internship
# Models: SVM & XGBoost
# Dataset: UCI Heart Disease (Cleveland)
# =============================================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, roc_auc_score, confusion_matrix,
                             classification_report, roc_curve)
from xgboost import XGBClassifier

# ─────────────────────────────────────────────
# STEP 1: LOAD DATA
# ─────────────────────────────────────────────
print("=" * 60)
print("STEP 1: LOADING DATA")
print("=" * 60)

columns = ['age', 'sex', 'cp', 'trestbps', 'chol', 'fbs',
           'restecg', 'thalach', 'exang', 'oldpeak', 'slope',
           'ca', 'thal', 'target']

df = pd.read_csv('processed.cleveland.data', header=None, names=columns,
                 na_values='?')

print(f"Shape: {df.shape}")
print(f"\nFirst 5 rows:\n{df.head()}")
print(f"\nData types:\n{df.dtypes}")


# ─────────────────────────────────────────────
# STEP 2: DATA CLEANING
# ─────────────────────────────────────────────
print("\n" + "=" * 60)
print("STEP 2: DATA CLEANING")
print("=" * 60)

print(f"\nMissing values before cleaning:\n{df.isnull().sum()}")

# Fill missing values with column median
df.loc[:, 'ca']   = df['ca'].fillna(df['ca'].median())
df.loc[:, 'thal'] = df['thal'].fillna(df['thal'].median())

print(f"\nMissing values after cleaning:\n{df.isnull().sum()}")

# Binarize target: 0 = no disease, 1 = disease (values 1-4 → 1)
df['target'] = df['target'].apply(lambda x: 1 if x > 0 else 0)

print(f"\nTarget distribution:\n{df['target'].value_counts()}")
print(f"\nBasic statistics:\n{df.describe()}")


# ─────────────────────────────────────────────
# STEP 3: VISUALIZATION
# ─────────────────────────────────────────────
print("\n" + "=" * 60)
print("STEP 3: VISUALIZATION")
print("=" * 60)

fig, axes = plt.subplots(2, 3, figsize=(16, 10))
fig.suptitle('Heart Disease Dataset — Exploratory Analysis', fontsize=16, fontweight='bold')

# 1. Target distribution
axes[0, 0].bar(['No Disease (0)', 'Disease (1)'],
               df['target'].value_counts().sort_index(),
               color=['#2196F3', '#F44336'], edgecolor='black')
axes[0, 0].set_title('Target Distribution')
axes[0, 0].set_ylabel('Count')
for i, v in enumerate(df['target'].value_counts().sort_index()):
    axes[0, 0].text(i, v + 1, str(v), ha='center', fontweight='bold')

# 2. Age distribution by target
axes[0, 1].hist(df[df['target'] == 0]['age'], bins=20, alpha=0.6,
                color='#2196F3', label='No Disease', edgecolor='black')
axes[0, 1].hist(df[df['target'] == 1]['age'], bins=20, alpha=0.6,
                color='#F44336', label='Disease', edgecolor='black')
axes[0, 1].set_title('Age Distribution by Target')
axes[0, 1].set_xlabel('Age')
axes[0, 1].set_ylabel('Count')
axes[0, 1].legend()

# 3. Sex vs Target
sex_target = df.groupby(['sex', 'target']).size().unstack()
sex_target.plot(kind='bar', ax=axes[0, 2], color=['#2196F3', '#F44336'],
                edgecolor='black', rot=0)
axes[0, 2].set_title('Sex vs Heart Disease')
axes[0, 2].set_xticklabels(['Female (0)', 'Male (1)'])
axes[0, 2].set_ylabel('Count')
axes[0, 2].legend(['No Disease', 'Disease'])

# 4. Chest pain type vs Target
cp_target = df.groupby(['cp', 'target']).size().unstack()
cp_target.plot(kind='bar', ax=axes[1, 0], color=['#2196F3', '#F44336'],
               edgecolor='black', rot=0)
axes[1, 0].set_title('Chest Pain Type vs Heart Disease')
axes[1, 0].set_xlabel('Chest Pain Type')
axes[1, 0].set_ylabel('Count')
axes[1, 0].legend(['No Disease', 'Disease'])

# 5. Correlation heatmap
corr = df.corr()
mask = np.triu(np.ones_like(corr, dtype=bool))
sns.heatmap(corr, ax=axes[1, 1], annot=True, fmt='.2f', cmap='coolwarm',
            mask=mask, linewidths=0.5, annot_kws={'size': 7})
axes[1, 1].set_title('Feature Correlation Heatmap')

# 6. Max Heart Rate vs Age (scatter)
colors = df['target'].map({0: '#2196F3', 1: '#F44336'})
axes[1, 2].scatter(df['age'], df['thalach'], c=colors, alpha=0.6, edgecolors='black', linewidths=0.3)
axes[1, 2].set_title('Age vs Max Heart Rate')
axes[1, 2].set_xlabel('Age')
axes[1, 2].set_ylabel('Max Heart Rate (thalach)')
from matplotlib.patches import Patch
axes[1, 2].legend(handles=[Patch(color='#2196F3', label='No Disease'),
                            Patch(color='#F44336', label='Disease')])

plt.tight_layout()
plt.savefig('eda_plots.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: eda_plots.png")


# ─────────────────────────────────────────────
# STEP 4: FEATURE SELECTION & SPLITTING
# ─────────────────────────────────────────────
print("\n" + "=" * 60)
print("STEP 4: FEATURE SELECTION & TRAIN-TEST SPLIT")
print("=" * 60)

X = df.drop('target', axis=1)
y = df['target']

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)

print(f"Training samples : {X_train.shape[0]}")
print(f"Testing  samples : {X_test.shape[0]}")
print(f"Features         : {X.shape[1]}")

# Scale features (required for SVM)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled  = scaler.transform(X_test)


# ─────────────────────────────────────────────
# STEP 5: MODEL TRAINING
# ─────────────────────────────────────────────
print("\n" + "=" * 60)
print("STEP 5: MODEL TRAINING")
print("=" * 60)

# --- SVM ---
print("\nTraining SVM...")
svm_model = SVC(kernel='rbf', C=1.0, gamma='scale', probability=True, random_state=42)
svm_model.fit(X_train_scaled, y_train)
print("SVM training complete.")

# --- XGBoost ---
print("\nTraining XGBoost...")
xgb_model = XGBClassifier(n_estimators=100, max_depth=4, learning_rate=0.1,
                           use_label_encoder=False, eval_metric='logloss',
                           random_state=42)
xgb_model.fit(X_train_scaled, y_train)
print("XGBoost training complete.")


# ─────────────────────────────────────────────
# STEP 6: EVALUATION
# ─────────────────────────────────────────────
print("\n" + "=" * 60)
print("STEP 6: MODEL EVALUATION")
print("=" * 60)

def evaluate_model(name, model, X_test, y_test):
    y_pred  = model.predict(X_test)
    y_prob  = model.predict_proba(X_test)[:, 1]

    acc  = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred)
    rec  = recall_score(y_test, y_pred)
    f1   = f1_score(y_test, y_pred)
    auc  = roc_auc_score(y_test, y_prob)
    cv   = cross_val_score(model, X_test, y_test, cv=5, scoring='accuracy').mean()

    print(f"\n{'─'*40}")
    print(f"  {name}")
    print(f"{'─'*40}")
    print(f"  Accuracy       : {acc:.4f}")
    print(f"  Precision      : {prec:.4f}")
    print(f"  Recall         : {rec:.4f}")
    print(f"  F1-Score       : {f1:.4f}")
    print(f"  ROC-AUC        : {auc:.4f}")
    print(f"  CV Accuracy    : {cv:.4f}")
    print(f"\nClassification Report:\n{classification_report(y_test, y_pred, target_names=['No Disease','Disease'])}")

    return y_pred, y_prob, {'Accuracy': acc, 'Precision': prec,
                            'Recall': rec, 'F1-Score': f1, 'ROC-AUC': auc}

svm_pred, svm_prob, svm_metrics = evaluate_model("SVM (RBF Kernel)", svm_model, X_test_scaled, y_test)
xgb_pred, xgb_prob, xgb_metrics = evaluate_model("XGBoost", xgb_model, X_test_scaled, y_test)


# ─────────────────────────────────────────────
# STEP 7: RESULT PLOTS
# ─────────────────────────────────────────────
print("\n" + "=" * 60)
print("STEP 7: RESULT VISUALIZATION")
print("=" * 60)

fig, axes = plt.subplots(1, 3, figsize=(18, 5))
fig.suptitle('Model Evaluation Results', fontsize=15, fontweight='bold')

# Confusion Matrix — SVM
cm_svm = confusion_matrix(y_test, svm_pred)
sns.heatmap(cm_svm, annot=True, fmt='d', cmap='Blues', ax=axes[0],
            xticklabels=['No Disease', 'Disease'],
            yticklabels=['No Disease', 'Disease'])
axes[0].set_title('Confusion Matrix — SVM')
axes[0].set_xlabel('Predicted')
axes[0].set_ylabel('Actual')

# Confusion Matrix — XGBoost
cm_xgb = confusion_matrix(y_test, xgb_pred)
sns.heatmap(cm_xgb, annot=True, fmt='d', cmap='Oranges', ax=axes[1],
            xticklabels=['No Disease', 'Disease'],
            yticklabels=['No Disease', 'Disease'])
axes[1].set_title('Confusion Matrix — XGBoost')
axes[1].set_xlabel('Predicted')
axes[1].set_ylabel('Actual')

# ROC Curves
fpr_svm, tpr_svm, _ = roc_curve(y_test, svm_prob)
fpr_xgb, tpr_xgb, _ = roc_curve(y_test, xgb_prob)

axes[2].plot(fpr_svm, tpr_svm, color='#2196F3', lw=2,
             label=f"SVM  (AUC = {svm_metrics['ROC-AUC']:.3f})")
axes[2].plot(fpr_xgb, tpr_xgb, color='#FF5722', lw=2,
             label=f"XGBoost (AUC = {xgb_metrics['ROC-AUC']:.3f})")
axes[2].plot([0, 1], [0, 1], 'k--', lw=1, label='Random Baseline')
axes[2].set_title('ROC Curves')
axes[2].set_xlabel('False Positive Rate')
axes[2].set_ylabel('True Positive Rate')
axes[2].legend()

plt.tight_layout()
plt.savefig('model_results.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: model_results.png")

# Metrics comparison bar chart
fig, ax = plt.subplots(figsize=(10, 5))
metrics_df = pd.DataFrame({'SVM': svm_metrics, 'XGBoost': xgb_metrics})
metrics_df.plot(kind='bar', ax=ax, color=['#2196F3', '#FF5722'],
                edgecolor='black', rot=0)
ax.set_title('SVM vs XGBoost — Metrics Comparison', fontsize=13, fontweight='bold')
ax.set_ylabel('Score')
ax.set_ylim(0, 1.1)
for container in ax.containers:
    ax.bar_label(container, fmt='%.3f', padding=2, fontsize=9)
ax.legend(loc='upper right')
plt.tight_layout()
plt.savefig('metrics_comparison.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: metrics_comparison.png")

# XGBoost Feature Importance
fig, ax = plt.subplots(figsize=(8, 5))
importance = pd.Series(xgb_model.feature_importances_, index=X.columns).sort_values()
importance.plot(kind='barh', ax=ax, color='#FF5722', edgecolor='black')
ax.set_title('XGBoost — Feature Importance', fontsize=13, fontweight='bold')
ax.set_xlabel('Importance Score')
plt.tight_layout()
plt.savefig('feature_importance.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: feature_importance.png")


# ─────────────────────────────────────────────
# STEP 8: SUMMARY
# ─────────────────────────────────────────────
print("\n" + "=" * 60)
print("STEP 8: FINAL SUMMARY")
print("=" * 60)

summary = pd.DataFrame({'SVM': svm_metrics, 'XGBoost': xgb_metrics}).round(4)
print(f"\n{summary}")

best = 'SVM' if svm_metrics['ROC-AUC'] > xgb_metrics['ROC-AUC'] else 'XGBoost'
print(f"\nBest model by ROC-AUC: {best}")
print("\nAll plots saved. Task 4 complete.")
